#ifndef WEAPONTYPE_H
#define WEAPONTYPE_H

namespace CounterStrike {
    enum class WeaponType {
        AK47 = 12,
        M4A1 = 13,
        AWP = 14,
        DEAGLE = 15,
        UMP45 = 16
    };
}

#endif 